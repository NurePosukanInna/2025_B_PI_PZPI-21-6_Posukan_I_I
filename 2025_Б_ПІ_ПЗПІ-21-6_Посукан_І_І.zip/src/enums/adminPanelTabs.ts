export enum AdminPanelTabs {
  Dashboard  = "dashboard",
  Users = "users",
  BoardGames = "boardGames",
  Classifiers = "classifiers"
}