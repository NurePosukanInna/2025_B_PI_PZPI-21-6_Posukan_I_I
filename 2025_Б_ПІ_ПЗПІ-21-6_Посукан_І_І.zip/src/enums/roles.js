export const roles = [
  { id: 0, name: 'Admin' },
 // { id: 1, name: 'Moderator' },
  { id: 2, name: 'Regular User' },
  { id: 3, name: 'Club Owner' }
];