export const BASE_URL = 'https://localhost:7000/api';
export const GOOGLE_CLIENT_ID = "210423375418-v5hdri66d6mu6v7ecgp5vd42ht1rn6kb.apps.googleusercontent.com";

